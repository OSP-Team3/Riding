# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 10:46:02 2019

@author: Joy
"""

import pandas as pd
import numpy as np
import os

base_dir="C:/Users/joy/Desktop/"
excel_file='User_test_data.xlsx'
excel_dir=os.path.join(base_dir,excel_file)

img_dir="C:/Users/joy/Desktop/profile_img/"

data=pd.read_excel(excel_dir)

user_id=1

f = open("insert_user_data.txt", 'w')

for i in range(len(data)):
    profile=img_dir+str(user_id)+".jpg"
    user_id=user_id+1
    insert_data="insert into User values ('"+data['name'][i]+"', '"+str(data['password'][i])+"', '"+data['email'][i]+"', '"+profile+"');\n"
    print(insert_data)
    f.write(insert_data)
    
f.close()
    