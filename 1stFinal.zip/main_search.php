﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>타봤어?</title>
  <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.1/themes/base/minified/jquery-ui.min.css" type="text/css" /> 
</head>
<body onload="init()">
  <?php
    $conn = new mysqli("localhost","root","1234","amuse");
    mysqli_set_charset($conn,'utf8');
    if(mysqli_connect_errno()){
	echo '<p>Error: Could not connect to databse.<br/>
	Please try agian later.</p>';
	exit;
    }
  ?>

   <div id="wrapper">
          <header id="main_header">
        <a href=main.php style="text-decoration:none;color:white;">
            <h1>타봤어?</h1>
            <h4>
                <font color="#FFE400"> 놀이기구 리뷰 어플리케이션</font>
            </h4>
        </a>
    </header>
      <section class="main_section">
         <div id = "basic">
	<p align = "right">
        <?php
        session_start();
if (!isset($_SESSION['user_id']))
{
    ?>
        <a href="./login.html">로그인/회원가입</a>
        <?php
}else{
    ?>
    <a href="writeReview.php">글쓰기</a>
	<a href="logout.php">로그아웃</a>
	<a href="LAB_2.php">내정보</a>
            </p>  
        <?php
}
        ?>
         </div>

         <div id = "search">
	<form name = 'searchterm' action="main_search.php" method="get"> 
	<input class='auto' name="searchterm" type="text" size="40" placeholder="해시태그를 입력하세요" />
	<button type="submit" name="submit"> 검색</button>
            </form>
            <ul id="tag-list"></ul>
         </div>

         <?php $search_term = $_GET['searchterm']; ?>

         <div id="myTab">
            <button id="default" class="tab" onclick="openMenu('Gyung', this)">경주월드</button>
	<button class="tab" onclick="openMenu('Seoul', this)">서울랜드</button>
	<button class="tab" onclick="openMenu('Ever', this)">에버랜드</button> 
	<button class="tab" onclick="openMenu('Lotte', this)">롯데월드</button>
            <select id=displayOrder>
	     <option value selected>정렬</option>       
	     <option>인기순</option>   
	     <option>별점순</option>           
            </select>

             <div id="Gyung" class="content">
	    <p>
                       <?php
		    $query = "SELECT DISTINCT park_id, ride.ride_id, name, img_link, review.hash_tag FROM((((park LEFT JOIN ride on park.ride_id = ride.ride_id) LEFT JOIN ride_img on park.ride_id = ride_img.ride_id) LEFT JOIN review on park.ride_id = review.ride_id) LEFT JOIN hashtag on park.ride_id = hashtag.ride_id) WHERE review.hash_tag like '%$search_term%' AND park.park_id=1";
		    $result = mysqli_query($conn, $query);		    
                            while($row = mysqli_fetch_array($result)){
                       ?>
                       <div class="column">
	              <a href="http://localhost/inform_4.php?value=<?php echo($row['ride_id'])?>">
		    <img src="<?php echo $row['img_link']; ?>">
	              </a>
	              <p><?php echo $row['name'].'<br>'; ?></p>                   
                       </div>
                       <?php
                            }
                       ?>
	    </p>
             </div>

             <div id="Seoul" class="content">
	    <p>
                       <?php
		    $query = "SELECT DISTINCT park_id, ride.ride_id, name, img_link, satisfy, review.hash_tag FROM((((park LEFT JOIN ride on park.ride_id = ride.ride_id) LEFT JOIN ride_img on park.ride_id = ride_img.ride_id) LEFT JOIN review on park.ride_id = review.ride_id) LEFT JOIN hashtag on park.ride_id = hashtag.ride_id) WHERE review.hash_tag like '%$search_term%' AND park.park_id=2";
		    $result = mysqli_query($conn, $query);		    
                            while($row = mysqli_fetch_array($result)){
                       ?>
                       <div class="column">
	              <a href="http://localhost/inform_4.php?value=<?php echo($row['ride_id'])?>">
		    <img src="<?php echo $row['img_link']; ?>">
	              </a>
	              <p><?php echo $row['name'].'<br>'; ?></p>                   
                       </div>
                       <?php
                            }
                       ?>
	    </p>
             </div>

             <div id="Ever" class="content">
	    <p>
                       <?php
		    $query = "SELECT DISTINCT park_id, ride.ride_id, name, img_link, satisfy, review.hash_tag FROM((((park LEFT JOIN ride on park.ride_id = ride.ride_id) LEFT JOIN ride_img on park.ride_id = ride_img.ride_id) LEFT JOIN review on park.ride_id = review.ride_id) LEFT JOIN hashtag on park.ride_id = hashtag.ride_id) WHERE review.hash_tag like '%$search_term%' AND park.park_id=3";
		    $result = mysqli_query($conn, $query);		    
                            while($row = mysqli_fetch_array($result)){
                       ?>
                       <div class="column">
	              <a href="http://localhost/inform_4.php?value=<?php echo($row['ride_id'])?>">
		    <img src="<?php echo $row['img_link']; ?>">
	              </a>
	              <p><?php echo $row['name'].'<br>'; ?></p>                   
                       </div>
                       <?php
                            }
                       ?>
	    </p>
             </div>

             <div id="Lotte" class="content">
	    <p>
                       <?php
		    $query = "SELECT DISTINCT park_id, ride.ride_id, name, img_link, satisfy, review.hash_tag FROM((((park LEFT JOIN ride on park.ride_id = ride.ride_id) LEFT JOIN ride_img on park.ride_id = ride_img.ride_id) LEFT JOIN review on park.ride_id = review.ride_id) LEFT JOIN hashtag on park.ride_id = hashtag.ride_id) WHERE review.hash_tag like '%$search_term%' AND park.park_id=4";
		    $result = mysqli_query($conn, $query);		    
                            while($row = mysqli_fetch_array($result)){
                       ?>
                       <div class="column">
	              <a href="http://localhost/inform_4.php?value=<?php echo($row['ride_id'])?>">
		    <img src="<?php echo $row['img_link']; ?>">
	              </a>
	              <p><?php echo $row['name'].'<br>'; ?></p>                   
                       </div>
                       <?php
                            }
                       ?>
	    </p>
             </div>

    <?php mysqli_close($conn); ?>

    </section>
    </div>
    <script>
        function selectCont(obj, opt) {
            var subContent, i;
            var value = obj.value;
            subContent = document.getElementsByClassName("subCont"+opt);
            for (i = 0; i < subContent.length; i++) {
                subContent[i].style.display = "none";
            }
            if (value == "X") {
                for (i = 0; i < subContent.length; i++) {
                    subContent[i].style.display = "block";
                }
            } else {
                document.getElementById(value+opt).style.display = "block";
            }
        }
	function init(){
		var btn;
		btn=document.getElementById("default");
		btn.click();
	}
	function openMenu(target, evt) {

		var tabMenu, i, tabContent;

		tabContent=document.getElementsByClassName("content");
		for( i=0; i< tabContent.length; i++){
			tabContent[i].style.display="none";
		}
		tabMenu=document.getElementsByClassName("tab");
		for(i=0; i< tabMenu.length ;i++){
			tabMenu[i].className=tabMenu[i].className.replace(" active","");
		}
		document.getElementById(target).style.display="block";
		evt.className += " active";
	}
    function init(){
     var btn, i;
     btn = document.getElementsByClassName("tab");
     for(i=0;i<btn.length;i++){
         if(btn[i].value == 1){
             btn[i].click();
             break;
         }
     }
     }
    </script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>	
    <script type="text/javascript">
            $(function() {
	//autocomplete
	$(".auto").autocomplete({
		source: "autosearch.php",
		minLength: 1
	});				

    });
        
    </script>
</body>
</html>