<?php
$id=$_POST['id'];
$pw=$_POST['pw'];
$pwc=$_POST['pwc'];
$email=$_POST['email'];

if($pw!=$pwc)
{
    echo "wrong pw and pwc.";
    echo "<a href=signUp.html>back</a>";
}
if($id==NULL || $pw==NULL ||$email==NULL){
    echo "빈칸을 모두 채워주세요";
    echo "<p/>";
    echo "<a href=signUp.html>돌아가기</a>";
    exit();
}
$mysqli=mysqli_connect("localhost","bookorama","bookorama123","amuse");
$check="SELECT * from user where name = '$id'";
$result = $mysqli->query($check);
if($result->num_rows == 1){
    echo "동일한 아이디가 존재합니다.";
    echo "<p/>";
    echo "<a href=signUp.html>돌아가기</a>";
    exit();
}
$signup =mysqli_query($mysqli,"INSERT INTO user (name, password,email) VALUES ('$id','$pw','$email')");
if($signup){
    echo "회원가입 성공";
    echo "<p/>";
    echo "<a href=login.html>로그인 하러가기</a>";
}
?>