<?php
    $conn = new mysqli("localhost","root","1234","num1");
    mysqli_set_charset($conn,'utf8');
    if(mysqli_connect_errno()){
	echo '<p>Error: Could not connect to databse.<br/>
	Please try agian later.</p>';
	exit;
    }


   $return_hash = array( );
   $keyword = $_GET['term'];
   $sql = "SELECT DISTINCT hashtag.hash_tag FROM ride LEFT JOIN hashtag on ride.ride_id=hashtag.ride_id WHERE hashtag.hash_tag like '%$keyword%' LIMIT 5";
   $result = mysqli_query($conn, $sql);
   while($row = mysqli_fetch_array($result)){
	$return_hash[] = $row['hash_tag'];
   }
   echo json_encode($return_hash);
   mysqli_close($conn);
?>