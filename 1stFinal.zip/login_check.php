<?php
session_start();
$id=$_POST['id'];
$pw=$_POST['pw'];
$mysqli=mysqli_connect("localhost","root","1234","amuse");
$check="SELECT * from user where name = '$id'";
$result=$mysqli->query($check);
if($result->num_rows==1){
	$row=$result->fetch_array(MYSQLI_ASSOC);
		if($row['password']==$pw){
		$_SESSION['user_id']=$id;
			if(isset($_SESSION['user_id'])){
				header('Location: ./main.php');
			}
			else{
				echo "?$)C8l? ?�???$m?";
			}
		}
		else{
			echo "??????9l? k9??k2?? ?$k?";
            echo "<p/>";
			echo "<a href=login.html>k!?78???$l???80</a>";
            echo "<p/>";
            echo "<a href=signUp.html>???j0�??/a>";
		}
}
else{
	echo "??????9l? k9??k2?? ?$k?";
    echo "<p/>";
	echo "<a href=login.html>k!?78???$l???80</a>";
    echo "<p/>";
	echo "<a href=signUp.html>???j0�??/a>";
}
?>

