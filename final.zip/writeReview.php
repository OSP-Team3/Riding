<?php
session_start();
$db=mysqli_connect("localhost","root","1234","amuse");
mysqli_set_charset($db,'utf8');
$kyung = $db->query("select ride_id, name from ride where ride_id like '1%'");
$seoul = $db->query("select ride_id, name from ride where ride_id like '2%'");
$ever = $db->query("select ride_id, name from ride where ride_id like '3%'");
$lotte = $db->query("select ride_id, name from ride where ride_id like '4%'");

$kyungID = array();
$seoulID =  array();
$everID =  array();
$lotteID =  array();
while($r = $kyung->fetch_array(MYSQLI_ASSOC)){
    $kyungID[]=$r;
}
while($r = $seoul->fetch_array(MYSQLI_ASSOC)){
    $seoulID[]=$r;
}
while($r = $ever->fetch_array(MYSQLI_ASSOC)){
    $everID[]=$r;
}
while($r = $lotte->fetch_array(MYSQLI_ASSOC)){
    $lotteID[]=$r;
}

$kyungs = count($kyungID);
$seouls = count($seoulID);
$evers = count($everID);
$lottes = count($lotteID);

$idx = 0;
echo("<script>");
echo("var s_selbox = new Array();s_selbox[0] = new Array();s_selbox[1] = new Array();s_selbox[2] = new Array();s_selbox[3] = new Array();</script>");
$c = 0;
for($c=0;$c<$kyungs;$c++){
    $key = $kyungID[$c]['ride_id'];
    $name = $kyungID[$c]['name'];
    echo("<script> s_selbox[0][\"$key\"]=\"$name\"</script>");    
}
$c = 0;
for($c=0;$c<$seouls;$c++){
    $key = $seoulID[$c]['ride_id'];
    $name = $seoulID[$c]['name'];
    echo("<script> s_selbox[1][\"$key\"]=\"$name\"</script>");    
}
$c = 0;
for($c=0;$c<$evers;$c++){
    $key = $everID[$c]['ride_id'];
    $name = $everID[$c]['name'];
    echo("<script> s_selbox[2][\"$key\"]=\"$name\"</script>");    
}
$c = 0;
for($c=0;$c<$lottes;$c++){
    $key = $lotteID[$c]['ride_id'];
    $name = $lotteID[$c]['name'];
    echo("<script> s_selbox[3][\"$key\"]=\"$name\"</script>");    
}

if (isset($_POST['send'])) {
    $title = $_POST['title'];
    $review = $_POST['review'];
    if(isset($_POST['thrill']) && isset($_POST['wait'])&& isset($_POST['wet'])&& isset($_POST['satisfy'])&& isset($_POST['op_time']) && $title != NULL && $review != NULL && isset($_POST['selplay']))
    {
        $user_name = $_SESSION['user_id'];
        $user_id = $db->query("select user_id from user where name = '$user_name'");
        $user_id = $user_id ->fetch_array(MYSQLI_ASSOC);
        $user_id = $user_id['user_id'];
//        $user_id = 12345;
        $ride_id = $_POST['selplay'];
        $wet = $_POST['wet'];
        $thrill = $_POST['thrill'];
        $op_time = $_POST['op_time'];
        $wait = $_POST['wait'];
        $satisfy = $_POST['satisfy'];
        $title = $_POST['title'];
        $review = $_POST['review'];
        $date = date("Y-m-d", time());
        $hash_tag = $_POST['hash_tag'];

        if($hash_tag != NULL){
            $b = explode("#",$hash_tag);
            $leng = count($b);
            $c = 0;
            for($c = 1;$c<$leng;$c++){
                $saveHash = $db->query("INSERT INTO hashtag (ride_id, hash_tag, count) VALUES('$ride_id','#$b[$c]', 1) on duplicate key update count = count +1");
            }
        }
        $save =$db->query("INSERT INTO review (user_id, ride_id, wet, thrill, op_time, wait, satisfy, title, summary, review, date, hash_tag) VALUES ('$user_id','$ride_id','$wet','$thrill','$op_time','$wait','$satisfy','$title', '$title','$review','$date','$hash_tag')");
        if($save == 1){
            echo"<script>alert('리뷰 저장을 완료하였습니다.'); document.location.href='./inform_4.php?value=".$ride_id."'</script>";
        }else{
            echo"<script>alert('이미 리뷰가 존재합니다.');document.location.href='./inform_4.php?value=".$ride_id."'</script>";
        }
    }
    else{
        echo "<script>alert('해시태그를 제외한 모든 항목을 선택, 기입해주세요!')</script>";
    }
}else{
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>타봤어?</title>
    <link rel="stylesheet" href="3review.css">
<script type="text/javascript">
    function itemChange(f) {
        var f_sel = f.first;
        var s_sel = f.second;
        var sel = f_sel.selectedIndex;
        for (var i = s_sel.length; i >= 0; i--) {
            s_sel.options[i] = null;
        }
        s_sel.options[0] = new Option("선택", "");
        var i = 0;
        for (var key in s_selbox[sel-1]) {
            var name = s_selbox[sel-1][key];
            s_sel.options[i] = new Option(name, key);
            i++;
        }
    }
</script>

<body>
    <header id="main_header">
        <a href=1_main.php style="text-decoration:none;color:white;">
            <h1>타봤어?</h1>
            <h4>
                <font color="#FFE400"> 놀이기구 리뷰 어플리케이션</font>
            </h4>
        </a>
    </header>
    <form action="./writeReview.php" method="post">
        <section class="wrapper1">
            *제목
            <input type="text" id="title" name="title" placeholder="제목:">
            <p />
            <select id="first" style="height:30px" name="selplace" onchange="itemChange(this.form);">
                <option value="0">-선택-</option>
                <option value="1">경주월드</option>
                <option value="2">서울랜드</option>
                <option value="3">에버랜드</option>
                <option value="4">롯데월드</option>
            </select>

                <select id="second" name="selplay">
                    <option value="0">-선택-</option>
                </select>
            <div id="starlabel1">
                스릴감
                <div class="thrill">
                    <input type="radio" id="star5" name="thrill" value="5" />
                    <label for="star5" title="text">★★★★★</label>
                    <input type="radio" id="star4" name="thrill" value="4" />
                    <label for="star4" title="text">★★★★</label>
                    <input type="radio" id="star3" name="thrill" value="3" />
                    <label for="star3" title="text">★★★</label>
                    <input type="radio" id="star2" name="thrill" value="2" />
                    <label for="star2" title="text">★★</label>
                    <input type="radio" id="star1" name="thrill" value="1" />
                    <label for="star1" title="text">★</label>
                </div>
            </div>
            <div id="starlabel2">
                운행시간
                <div class="op_time">
                    <input type="radio" id="star55" name="op_time" value="5" />
                    <label for="star55" title="text">★★★★★</label>
                    <input type="radio" id="star44" name="op_time" value="4" />
                    <label for="star44" title="text">★★★★</label>
                    <input type="radio" id="star33" name="op_time" value="3" />
                    <label for="star33" title="text">★★★</label>
                    <input type="radio" id="star22" name="op_time" value="2" />
                    <label for="star22" title="text">★★</label>
                    <input type="radio" id="star11" name="op_time" value="1" />
                    <label for="star11" title="text">★</label>
                </div>
            </div>
            <div id="starlabel3">
                대기시간
                <div class="wait">
                    <input type="radio" id="star555" name="wait" value="5" />
                    <label for="star555" title="text">★★★★★</label>
                    <input type="radio" id="star444" name="wait" value="4" />
                    <label for="star444" title="text">★★★★</label>
                    <input type="radio" id="star333" name="wait" value="3" />
                    <label for="star333" title="text">★★★</label>
                    <input type="radio" id="star222" name="wait" value="2" />
                    <label for="star222" title="text">★★</label>
                    <input type="radio" id="star111" name="wait" value="1" />
                    <label for="star111" title="text">★</label>
                </div>
            </div>
            <div id="starlabel4">
                젖음
                <div class="wet">
                    <input type="radio" id="star5555" name="wet" value="5" />
                    <label for="star5555" title="text">★★★★★</label>
                    <input type="radio" id="star4444" name="wet" value="4" />
                    <label for="star4444" title="text">★★★★</label>
                    <input type="radio" id="star3333" name="wet" value="3" />
                    <label for="star3333" title="text">★★★</label>
                    <input type="radio" id="star2222" name="wet" value="2" />
                    <label for="star2222" title="text">★★</label>
                    <input type="radio" id="star1111" name="wet" value="1" />
                    <label for="star1111" title="text">★</label>
                </div>
            </div>
            <div id="starlabel5">
                만족도
                <div class="satisfy">
                    <input type="radio" id="star55555" name="satisfy" value="5" />
                    <label for="star55555" title="text">★★★★★</label>
                    <input type="radio" id="star44444" name="satisfy" value="4" />
                    <label for="star44444" title="text">★★★★</label>
                    <input type="radio" id="star33333" name="satisfy" value="3" />
                    <label for="star33333" title="text">★★★</label>
                    <input type="radio" id="star22222" name="satisfy" value="2" />
                    <label for="star22222" title="text">★★</label>
                    <input type="radio" id="star11111" name="satisfy" value="1" />
                    <label for="star11111" title="text">★</label>
                </div>
            </div>
        </section>
        <p />
        <section id="wrapper2">
            *리뷰작성
            <textarea id="reviewtext" name="review" cols="40" rows="10" placeholder="리뷰작성"></textarea>
            <p />
            <input type="text" id="hashtagtext" name="hash_tag" placeholder="#해시태그" />
            <br />
            <input id="btn2" type="submit" name="send" value="확인">
        </section>
    </form>
</body>

</html>