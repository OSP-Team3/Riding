<?php
session_start();
$db=mysqli_connect("localhost","root","1234","amuse");
mysqli_set_charset($db,'utf8');

$user_name = $_SESSION['user_id'];
$user_id = $db->query("select user_id from user where name = '$user_name'");
$user_id = $user_id ->fetch_array(MYSQLI_ASSOC);
$user_id = $user_id['user_id'];

$selectedRide = $_GET['ride'];
$rideName = $db->query("select name from ride where ride_id = '$selectedRide'");
$ridePark = $db->query("select park_id from park where ride_id = '$selectedRide'");
$rideName = $rideName ->fetch_array(MYSQLI_ASSOC);
$rideName = $rideName['name'];
$ridePark = $ridePark -> fetch_array(MYSQLI_ASSOC);
$parkID= $ridePark['park_id'];
if ($ridePark['park_id'] == 1){
    $ridePark='경주월드';
}elseif ($ridePark['park_id']==2){
    $ridePark='서울랜드';    
}elseif( $ridePark['park_id']==3){
    $ridePark='에버랜드';    
}else{
    $ridePark='롯데월드';    
}
echo("<script>");
echo("var park = '$ridePark'; var ride = '$rideName';var park_val = '$parkID';var ride_val = '$selectedRide';</script>");


$review = $db->query("select * from review where ride_id='$selectedRide' and user_id='$user_id'");
$review = $review->fetch_array(MYSQLI_ASSOC);
$originalTitle = $review['title'];
$originalThrill = $review['thrill'];
$originalOP = $review['op_time'];
$originalWait = $review['wait'];
$originalWet = $review['wet'];
$originalSat = $review['satisfy'];
$originalReview = $review['review'];
$originalHash = $review['hash_tag'];
if($originalHash != NULL){
    $b = explode("#",$originalHash);
    $leng = count($b);
    $c = 0;
    for($c = 1;$c<$leng;$c++){
        $selectHash = $db->query("select count from hashtag where ride_id='$selectedRide' and hash_tag = '#$b[$c]'");
        $selectHash = $selectHash->fetch_array(MYSQLI_ASSOC);
        if($selectHash['count'] == 1){
            $deleteHash = $db->query("delete from hashtag where ride_id='$selectedRide' and hash_tag = '#$b[$c]'");
        }elseif($selectHash['count'] >1){
            $deleteHash = $db->query("insert into hashtag (ride_id, hash_tag, count) VALUES('$selectedRide','#$b[$c]', 1) on duplicate key update count = count - 1");
        }
    }
}

if (isset($_POST['send'])) {
    $title = $_POST['title'];
    $review = $_POST['review'];
    if(isset($_POST['thrill']) && isset($_POST['wait'])&& isset($_POST['wet'])&& isset($_POST['satisfy'])&& isset($_POST['op_time']) && $title != NULL && $review != NULL && isset($_POST['selplay']))
    {
        $wet = $_POST['wet'];
        $thrill = $_POST['thrill'];
        $op_time = $_POST['op_time'];
        $wait = $_POST['wait'];
        $satisfy = $_POST['satisfy'];
        $title = $_POST['title'];
        $review = $_POST['review'];
        $date = date("Y-m-d", time());
        $hash_tag = $_POST['hash_tag'];
//        $mycheck = "<script>document.write(check);</script>";
//        echo $mycheck;
//        if($mycheck){
            if($hash_tag != NULL){
                $b = explode("#",$hash_tag);
                $leng = count($b);
                $c = 0;
                for($c = 1;$c<$leng;$c++){
                    $saveHash = $db->query("INSERT INTO hashtag (ride_id, hash_tag, count) VALUES('$selectedRide','#$b[$c]', 1) on duplicate key update count = count +1");
                }
            }
            $save =$db->query("REPLACE INTO review (user_id, ride_id, wet, thrill, op_time, wait, satisfy, title, summary, review, date, hash_tag) VALUES ('$user_id','$selectedRide','$wet','$thrill','$op_time','$wait','$satisfy','$title', '$title','$review','$date','$hash_tag')");
            if($save == 1){
                echo"<script>alert('리뷰 저장을 완료하였습니다.'); document.location.href='./inform_4.php?value=".$selectedRide."'</script>";
            }
//            else{
//                echo mysqli_error($db);
//            }
//        }
//        else{
//           header('Location: ./inform_4.php?value='.$selectedRide);
//        }
    }
    else{
        echo "<script>alert('해시태그를 제외한 모든 항목을 선택, 기입해주세요!')</script>";
    }
}
else{
    
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>타봤어?</title>
    <link rel="stylesheet" href="3review.css">
</head>
<script type="text/javascript">
    function init(f) {
        var f_sel = f.first;
        var s_sel = f.second;
        f_sel.options[0]= new Option(park," ");
        s_sel.options[0]= new Option(ride," ");
    }
</script>

<body onload="init(this.form)">
    <header id="main_header">
        <a href=1_main.php style="text-decoration:none;color:white;">
            <h1>타봤어?</h1>
            <h4>
                <font color="#FFE400"> 놀이기구 리뷰 어플리케이션</font>
            </h4>
        </a>
    </header>
    <form action="./reWrite.php?ride=<?php echo($selectedRide)?>" method="post" name="form">
        <section class="wrapper1">
            *제목
            <input value="<?php echo($originalTitle) ?>" type="text" id="title" name="title"  >
            <p />
            <select id="first" style="height:30px" name="selplace">
            </select>
            <select id="second" style="height:30px" name="selplay">
            </select>
            <div id="starlabel1">
                스릴감
                <div class="thrill">
                    <?php
    switch($originalThrill){
        case 1:
            ?>
                    <input type="radio" id="star5" name="thrill" value="5" />
                    <label for="star5" title="text">★★★★★</label>
                    <input type="radio" id="star4" name="thrill" value="4" />
                    <label for="star4" title="text">★★★★</label>
                    <input type="radio" id="star3" name="thrill" value="3" />
                    <label for="star3" title="text">★★★</label>
                    <input type="radio" id="star2" name="thrill" value="2" />
                    <label for="star2" title="text">★★</label>
                    <input type="radio" id="star1" name="thrill" value="1" checked/>
                    <label for="star1" title="text">★</label>
            <?php
            break;
        case 2: ?>
                    <input type="radio" id="star5" name="thrill" value="5" />
                    <label for="star5" title="text">★★★★★</label>
                    <input type="radio" id="star4" name="thrill" value="4" />
                    <label for="star4" title="text">★★★★</label>
                    <input type="radio" id="star3" name="thrill" value="3" />
                    <label for="star3" title="text">★★★</label>
                    <input type="radio" id="star2" name="thrill" value="2" checked/>
                    <label for="star2" title="text">★★</label>
                    <input type="radio" id="star1" name="thrill" value="1" />
                    <label for="star1" title="text">★</label>
                    <?php
            break;
        case 3: ?>
                    <input type="radio" id="star5" name="thrill" value="5" />
                    <label for="star5" title="text">★★★★★</label>
                    <input type="radio" id="star4" name="thrill" value="4" />
                    <label for="star4" title="text">★★★★</label>
                    <input type="radio" id="star3" name="thrill" value="3" checked/>
                    <label for="star3" title="text">★★★</label>
                    <input type="radio" id="star2" name="thrill" value="2" />
                    <label for="star2" title="text">★★</label>
                    <input type="radio" id="star1" name="thrill" value="1" />
                    <label for="star1" title="text">★</label>
                    <?php
            break;
        case 4: ?>
                    <input type="radio" id="star5" name="thrill" value="5" />
                    <label for="star5" title="text">★★★★★</label>
                    <input type="radio" id="star4" name="thrill" value="4" checked/>
                    <label for="star4" title="text">★★★★</label>
                    <input type="radio" id="star3" name="thrill" value="3" />
                    <label for="star3" title="text">★★★</label>
                    <input type="radio" id="star2" name="thrill" value="2" />
                    <label for="star2" title="text">★★</label>
                    <input type="radio" id="star1" name="thrill" value="1" />
                    <label for="star1" title="text">★</label>
                    <?php
            break;
        case 5: ?>
                    <input type="radio" id="star5" name="thrill" value="5" checked/>
                    <label for="star5" title="text">★★★★★</label>
                    <input type="radio" id="star4" name="thrill" value="4" />
                    <label for="star4" title="text">★★★★</label>
                    <input type="radio" id="star3" name="thrill" value="3" />
                    <label for="star3" title="text">★★★</label>
                    <input type="radio" id="star2" name="thrill" value="2" />
                    <label for="star2" title="text">★★</label>
                    <input type="radio" id="star1" name="thrill" value="1" />
                    <label for="star1" title="text">★</label>
                    <?php
            break;
    }
          ?>
                </div>
            </div>
            <div id="starlabel2">
                운행시간
                <div class="op_time">
                    <?php
    switch($originalOP){
        case 1:
            ?>
                    <input type="radio" id="star55" name="op_time" value="5" />
                    <label for="star55" title="text">★★★★★</label>
                    <input type="radio" id="star44" name="op_time" value="4" />
                    <label for="star44" title="text">★★★★</label>
                    <input type="radio" id="star33" name="op_time" value="3" />
                    <label for="star33" title="text">★★★</label>
                    <input type="radio" id="star22" name="op_time" value="2" />
                    <label for="star22" title="text">★★</label>
                    <input type="radio" id="star11" name="op_time" value="1" checked/>
                    <label for="star11" title="text">★</label>
            <?php
            break;
        case 2: ?>
                    <input type="radio" id="star55" name="op_time" value="5" />
                    <label for="star55" title="text">★★★★★</label>
                    <input type="radio" id="star44" name="op_time" value="4" />
                    <label for="star44" title="text">★★★★</label>
                    <input type="radio" id="star33" name="op_time" value="3" />
                    <label for="star33" title="text">★★★</label>
                    <input type="radio" id="star22" name="op_time" value="2" checked/>
                    <label for="star22" title="text">★★</label>
                    <input type="radio" id="star11" name="op_time" value="1" />
                    <label for="star11" title="text">★</label>
                    <?php
            break;
        case 3: ?>
                    <input type="radio" id="star55" name="op_time" value="5" />
                    <label for="star55" title="text">★★★★★</label>
                    <input type="radio" id="star44" name="op_time" value="4" />
                    <label for="star44" title="text">★★★★</label>
                    <input type="radio" id="star33" name="op_time" value="3" checked/>
                    <label for="star33" title="text">★★★</label>
                    <input type="radio" id="star22" name="op_time" value="2" />
                    <label for="star22" title="text">★★</label>
                    <input type="radio" id="star11" name="op_time" value="1" />
                    <label for="star11" title="text">★</label>
                    <?php
            break;
        case 4: ?>
                    <input type="radio" id="star55" name="op_time" value="5" />
                    <label for="star55" title="text">★★★★★</label>
                    <input type="radio" id="star44" name="op_time" value="4" checked/>
                    <label for="star44" title="text">★★★★</label>
                    <input type="radio" id="star33" name="op_time" value="3" />
                    <label for="star33" title="text">★★★</label>
                    <input type="radio" id="star22" name="op_time" value="2" />
                    <label for="star22" title="text">★★</label>
                    <input type="radio" id="star11" name="op_time" value="1" />
                    <label for="star11" title="text">★</label>
                    <?php
            break;
        case 5: ?>
                    <input type="radio" id="star55" name="op_time" value="5" checked/>
                    <label for="star55" title="text">★★★★★</label>
                    <input type="radio" id="star44" name="op_time" value="4" />
                    <label for="star44" title="text">★★★★</label>
                    <input type="radio" id="star33" name="op_time" value="3" />
                    <label for="star33" title="text">★★★</label>
                    <input type="radio" id="star22" name="op_time" value="2" />
                    <label for="star22" title="text">★★</label>
                    <input type="radio" id="star11" name="op_time" value="1" />
                    <label for="star11" title="text">★</label>
                    <?php
            break;
    }
          ?>
                </div>
            </div>
            <div id="starlabel3">
                대기시간
                <div class="wait">
                    <?php
    switch($originalWait){
        case 1:
            ?>
                    <input type="radio" id="star555" name="wait" value="5" />
                    <label for="star555" title="text">★★★★★</label>
                    <input type="radio" id="star444" name="wait" value="4" />
                    <label for="star444" title="text">★★★★</label>
                    <input type="radio" id="star333" name="wait" value="3" />
                    <label for="star333" title="text">★★★</label>
                    <input type="radio" id="star222" name="wait" value="2" />
                    <label for="star222" title="text">★★</label>
                    <input type="radio" id="star111" name="wait" value="1" checked />
                    <label for="star111" title="text">★</label>
            <?php
            break;
        case 2: ?>
                    <input type="radio" id="star555" name="wait" value="5" />
                    <label for="star555" title="text">★★★★★</label>
                    <input type="radio" id="star444" name="wait" value="4" />
                    <label for="star444" title="text">★★★★</label>
                    <input type="radio" id="star333" name="wait" value="3" />
                    <label for="star333" title="text">★★★</label>
                    <input type="radio" id="star222" name="wait" value="2" checked />
                    <label for="star222" title="text">★★</label>
                    <input type="radio" id="star111" name="wait" value="1" />
                    <label for="star111" title="text">★</label>
                    <?php
            break;
        case 3: ?>
                    <input type="radio" id="star555" name="wait" value="5" />
                    <label for="star555" title="text">★★★★★</label>
                    <input type="radio" id="star444" name="wait" value="4" />
                    <label for="star444" title="text">★★★★</label>
                    <input type="radio" id="star333" name="wait" value="3" checked/>
                    <label for="star333" title="text">★★★</label>
                    <input type="radio" id="star222" name="wait" value="2" />
                    <label for="star222" title="text">★★</label>
                    <input type="radio" id="star111" name="wait" value="1" />
                    <label for="star111" title="text">★</label>
                    <?php
            break;
        case 4: ?>
                    <input type="radio" id="star555" name="wait" value="5" />
                    <label for="star555" title="text">★★★★★</label>
                    <input type="radio" id="star444" name="wait" value="4" checked/>
                    <label for="star444" title="text">★★★★</label>
                    <input type="radio" id="star333" name="wait" value="3" />
                    <label for="star333" title="text">★★★</label>
                    <input type="radio" id="star222" name="wait" value="2" />
                    <label for="star222" title="text">★★</label>
                    <input type="radio" id="star111" name="wait" value="1" />
                    <label for="star111" title="text">★</label>
                    <?php
            break;
        case 5: ?>
                    <input type="radio" id="star555" name="wait" value="5" checked/>
                    <label for="star555" title="text">★★★★★</label>
                    <input type="radio" id="star444" name="wait" value="4" />
                    <label for="star444" title="text">★★★★</label>
                    <input type="radio" id="star333" name="wait" value="3" />
                    <label for="star333" title="text">★★★</label>
                    <input type="radio" id="star222" name="wait" value="2" />
                    <label for="star222" title="text">★★</label>
                    <input type="radio" id="star111" name="wait" value="1" />
                    <label for="star111" title="text">★</label>
                    <?php
            break;
    }
          ?>
                </div>
            </div>
            <div id="starlabel4">
                젖음
                <div class="wet">
                    <?php
    switch($originalWet){
        case 1:
            ?>
                    <input type="radio" id="star5555" name="wet" value="5" />
                    <label for="star5555" title="text">★★★★★</label>
                    <input type="radio" id="star4444" name="wet" value="4" />
                    <label for="star4444" title="text">★★★★</label>
                    <input type="radio" id="star3333" name="wet" value="3" />
                    <label for="star3333" title="text">★★★</label>
                    <input type="radio" id="star2222" name="wet" value="2" />
                    <label for="star2222" title="text">★★</label>
                    <input type="radio" id="star1111" name="wet" value="1" checked/>
                    <label for="star1111" title="text">★</label>
            <?php
            break;
        case 2: ?>
                    <input type="radio" id="star5555" name="wet" value="5" />
                    <label for="star5555" title="text">★★★★★</label>
                    <input type="radio" id="star4444" name="wet" value="4" />
                    <label for="star4444" title="text">★★★★</label>
                    <input type="radio" id="star3333" name="wet" value="3" />
                    <label for="star3333" title="text">★★★</label>
                    <input type="radio" id="star2222" name="wet" value="2" checked/>
                    <label for="star2222" title="text">★★</label>
                    <input type="radio" id="star1111" name="wet" value="1" />
                    <label for="star1111" title="text">★</label>
                    <?php
            break;
        case 3: ?>
                    <input type="radio" id="star5555" name="wet" value="5" />
                    <label for="star5555" title="text">★★★★★</label>
                    <input type="radio" id="star4444" name="wet" value="4" />
                    <label for="star4444" title="text">★★★★</label>
                    <input type="radio" id="star3333" name="wet" value="3" checked/>
                    <label for="star3333" title="text">★★★</label>
                    <input type="radio" id="star2222" name="wet" value="2" />
                    <label for="star2222" title="text">★★</label>
                    <input type="radio" id="star1111" name="wet" value="1" />
                    <label for="star1111" title="text">★</label>
                    <?php
            break;
        case 4: ?>
                    <input type="radio" id="star5555" name="wet" value="5" />
                    <label for="star5555" title="text">★★★★★</label>
                    <input type="radio" id="star4444" name="wet" value="4" checked/>
                    <label for="star4444" title="text">★★★★</label>
                    <input type="radio" id="star3333" name="wet" value="3" />
                    <label for="star3333" title="text">★★★</label>
                    <input type="radio" id="star2222" name="wet" value="2" />
                    <label for="star2222" title="text">★★</label>
                    <input type="radio" id="star1111" name="wet" value="1" />
                    <label for="star1111" title="text">★</label>
                    <?php
            break;
        case 5: ?>
                   <input type="radio" id="star5555" name="wet" value="5" checked/>
                    <label for="star5555" title="text">★★★★★</label>
                    <input type="radio" id="star4444" name="wet" value="4" />
                    <label for="star4444" title="text">★★★★</label>
                    <input type="radio" id="star3333" name="wet" value="3" />
                    <label for="star3333" title="text">★★★</label>
                    <input type="radio" id="star2222" name="wet" value="2" />
                    <label for="star2222" title="text">★★</label>
                    <input type="radio" id="star1111" name="wet" value="1" />
                    <label for="star1111" title="text">★</label>
                    <?php
            break;
    }
          ?>
                </div>
            </div>
            <div id="starlabel5">
                만족도
                <div class="satisfy">
                    <?php
    switch($originalSat){
        case 1:
            ?>
                    <input type="radio" id="star55555" name="satisfy" value="5" />
                    <label for="star55555" title="text">★★★★★</label>
                    <input type="radio" id="star44444" name="satisfy" value="4" />
                    <label for="star44444" title="text">★★★★</label>
                    <input type="radio" id="star33333" name="satisfy" value="3" />
                    <label for="star33333" title="text">★★★</label>
                    <input type="radio" id="star22222" name="satisfy" value="2" />
                    <label for="star22222" title="text">★★</label>
                    <input type="radio" id="star11111" name="satisfy" value="1" checked/>
                    <label for="star11111" title="text">★</label>
            <?php
            break;
        case 2: ?>
                    <input type="radio" id="star55555" name="satisfy" value="5" />
                    <label for="star55555" title="text">★★★★★</label>
                    <input type="radio" id="star44444" name="satisfy" value="4" />
                    <label for="star44444" title="text">★★★★</label>
                    <input type="radio" id="star33333" name="satisfy" value="3" />
                    <label for="star33333" title="text">★★★</label>
                    <input type="radio" id="star22222" name="satisfy" value="2" checked/>
                    <label for="star22222" title="text">★★</label>
                    <input type="radio" id="star11111" name="satisfy" value="1" />
                    <label for="star11111" title="text">★</label>
                    <?php
            break;
        case 3: ?>
                    <input type="radio" id="star55555" name="satisfy" value="5" />
                    <label for="star55555" title="text">★★★★★</label>
                    <input type="radio" id="star44444" name="satisfy" value="4" />
                    <label for="star44444" title="text">★★★★</label>
                    <input type="radio" id="star33333" name="satisfy" value="3" checked />
                    <label for="star33333" title="text">★★★</label>
                    <input type="radio" id="star22222" name="satisfy" value="2" />
                    <label for="star22222" title="text">★★</label>
                    <input type="radio" id="star11111" name="satisfy" value="1" />
                    <label for="star11111" title="text">★</label>
                    <?php
            break;
        case 4: ?>
                    <input type="radio" id="star55555" name="satisfy" value="5" />
                    <label for="star55555" title="text">★★★★★</label>
                    <input type="radio" id="star44444" name="satisfy" value="4" checked />
                    <label for="star44444" title="text">★★★★</label>
                    <input type="radio" id="star33333" name="satisfy" value="3" />
                    <label for="star33333" title="text">★★★</label>
                    <input type="radio" id="star22222" name="satisfy" value="2" />
                    <label for="star22222" title="text">★★</label>
                    <input type="radio" id="star11111" name="satisfy" value="1" />
                    <label for="star11111" title="text">★</label>
                    <?php
            break;
        case 5: ?>
                    <input type="radio" id="star55555" name="satisfy" value="5" checked/>
                    <label for="star55555" title="text">★★★★★</label>
                    <input type="radio" id="star44444" name="satisfy" value="4" />
                    <label for="star44444" title="text">★★★★</label>
                    <input type="radio" id="star33333" name="satisfy" value="3" />
                    <label for="star33333" title="text">★★★</label>
                    <input type="radio" id="star22222" name="satisfy" value="2" />
                    <label for="star22222" title="text">★★</label>
                    <input type="radio" id="star11111" name="satisfy" value="1" />
                    <label for="star11111" title="text">★</label>
                    <?php
            break;
    }
          ?>
                </div>
            </div>
        </section>
        <p />
        <section id="wrapper2">
            *리뷰작성
            <textarea id="reviewtext" name="review" cols="40" rows="10"><?php echo($originalReview)?></textarea>
            <p />
            <input type="text" id="hashtagtext" name="hash_tag" value=<?php echo($originalHash)?>>
            <br />
            <input id="btn2" type="submit" name="send" value="확인">
        </section>
    </form>
</body>

</html>